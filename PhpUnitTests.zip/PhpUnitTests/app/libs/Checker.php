<?php

class Checker{
    
}